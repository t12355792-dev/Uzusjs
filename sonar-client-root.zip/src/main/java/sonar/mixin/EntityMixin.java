package sonar.mixin;

import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import sonar.module.ModuleManager;

@Mixin(Entity.class)
public class EntityMixin {
    @Inject(method = "slowMovement", at = @At("HEAD"), cancellable = true)
    private void sonar$noWeb(BlockState state, Vec3d multiplier, CallbackInfo ci) {
        if ((Object) this == MinecraftClient.getInstance().player
                && ModuleManager.noWeb != null && ModuleManager.noWeb.shouldCancel()) {
            ci.cancel();
        }
    }
}
