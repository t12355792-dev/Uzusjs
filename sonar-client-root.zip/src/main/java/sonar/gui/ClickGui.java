package sonar.gui;

import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import sonar.module.Module;
import sonar.module.ModuleManager;
import sonar.module.Setting;

import java.util.ArrayList;
import java.util.List;

public class ClickGui extends Screen {
    private static final int W = 300, H = 230;
    private static final int BG = 0xF0121118, PANEL = 0xFF1B1A24, CARD = 0xFF23222F, CARD_ON = 0xFF2E2250;
    private static final int ACC1 = 0xFFA855F7, ACC2 = 0xFF22D3EE, TEXT = 0xFFFFFFFF, DIM = 0xFF9A98AB;

    private final String[] tabs = {"Movements", "Combat"};
    private int tab = 1;
    private Module expanded;
    private Setting dragging; private int dragX, dragW;
    private final List<int[]> hit = new ArrayList<>();
    private final List<Object> hitObj = new ArrayList<>();

    public ClickGui() { super(Text.literal("Sonar Client")); }

    @Override public boolean shouldPause() { return false; }
    @Override public void renderBackground(DrawContext c, int mx, int my, float d) {}

    @Override
    public void render(DrawContext c, int mx, int my, float delta) {
        hit.clear(); hitObj.clear();
        c.fill(0, 0, width, height, 0x80000000);
        int x = (width - W) / 2, y = (height - H) / 2;

        c.fillGradient(x - 1, y - 1, x + W + 1, y + H + 1, ACC1, ACC2);
        c.fill(x, y, x + W, y + H, BG);

        c.fillGradient(x, y, x + W, y + 30, 0xFF2A1B4D, 0xFF121118);
        c.drawText(textRenderer, "SONAR", x + 12, y + 11, ACC2, true);
        c.drawText(textRenderer, "CLIENT", x + 12 + textRenderer.getWidth("SONAR "), y + 11, ACC1, true);
        c.drawText(textRenderer, "1.21.11", x + W - 44, y + 11, DIM, false);
        c.fillGradient(x, y + 29, x + W, y + 31, ACC1, ACC2);

        int tx = x + 10;
        for (int i = 0; i < tabs.length; i++) {
            int tw = 80;
            boolean sel = i == tab;
            c.fill(tx, y + 37, tx + tw, y + 55, sel ? CARD_ON : PANEL);
            if (sel) c.fillGradient(tx, y + 53, tx + tw, y + 55, ACC1, ACC2);
            c.drawText(textRenderer, tabs[i], tx + (tw - textRenderer.getWidth(tabs[i])) / 2, y + 42, sel ? TEXT : DIM, false);
            hit.add(new int[]{tx, y + 37, tx + tw, y + 55, 0, i}); hitObj.add(null);
            tx += tw + 6;
        }

        int top = y + 64;
        c.fill(x + 8, top - 4, x + W - 8, y + H - 8, PANEL);
        int cy = top;
        for (Module m : ModuleManager.byCategory(tabs[tab])) {
            c.fill(x + 12, cy, x + W - 12, cy + 24, m.enabled ? CARD_ON : CARD);
            if (m.enabled) c.fillGradient(x + 12, cy, x + 15, cy + 24, ACC1, ACC2);
            c.drawText(textRenderer, m.name, x + 22, cy + 4, TEXT, true);
            c.drawText(textRenderer, m.description, x + 22, cy + 14, DIM, false);
            String st = m.enabled ? "ON" : "OFF";
            c.drawText(textRenderer, st, x + W - 20 - textRenderer.getWidth(st), cy + 8, m.enabled ? ACC2 : DIM, true);
            hit.add(new int[]{x + 12, cy, x + W - 12, cy + 24, 1, 0}); hitObj.add(m);
            cy += 26;
            if (m == expanded) {
                for (Setting s : m.settings) {
                    int sx1 = x + 20, sx2 = x + W - 20;
                    c.fill(sx1, cy, sx2, cy + 18, 0xFF191822);
                    c.drawText(textRenderer, s.name, sx1 + 6, cy + 5, DIM, false);
                    if (s.type == Setting.Type.NUMBER) {
                        int bx1 = sx1 + 110, bx2 = sx2 - 40;
                        c.fill(bx1, cy + 8, bx2, cy + 11, 0xFF33313F);
                        int fill = bx1 + (int) ((bx2 - bx1) * s.ratio());
                        c.fillGradient(bx1, cy + 8, fill, cy + 11, ACC1, ACC2);
                        c.fill(fill - 2, cy + 5, fill + 2, cy + 14, TEXT);
                        hit.add(new int[]{bx1, cy, bx2, cy + 18, 3, bx2 - bx1}); hitObj.add(s);
                    } else {
                        hit.add(new int[]{sx1, cy, sx2, cy + 18, 2, 0}); hitObj.add(s);
                    }
                    String v = s.display();
                    c.drawText(textRenderer, v, sx2 - 6 - textRenderer.getWidth(v), cy + 5,
                            s.type == Setting.Type.BOOL && !s.bool ? DIM : ACC2, false);
                    cy += 20;
                }
                cy += 2;
            }
        }
        c.drawText(textRenderer, "ЛКМ - вкл/выкл   ПКМ - настройки", x + 10, y + H + 6, DIM, false);
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        double mx = click.x(), my = click.y(); int btn = click.button();
        for (int i = hit.size() - 1; i >= 0; i--) {
            int[] h = hit.get(i);
            if (mx < h[0] || mx > h[2] || my < h[1] || my > h[3]) continue;
            Object o = hitObj.get(i);
            switch (h[4]) {
                case 0 -> tab = h[5];
                case 1 -> { Module m = (Module) o;
                    if (btn == 0) m.toggle(); else if (btn == 1) expanded = expanded == m ? null : m; }
                case 2 -> { Setting s = (Setting) o;
                    if (s.type == Setting.Type.BOOL) s.bool = !s.bool; else s.cycle(); }
                case 3 -> { Setting s = (Setting) o; dragging = s; dragX = h[0]; dragW = h[5];
                    s.setFromRatio((mx - h[0]) / dragW); }
            }
            return true;
        }
        return super.mouseClicked(click, doubled);
    }

    @Override
    public boolean mouseDragged(Click click, double dx, double dy) {
        if (dragging != null) { dragging.setFromRatio((click.x() - dragX) / dragW); return true; }
        return super.mouseDragged(click, dx, dy);
    }

    @Override
    public boolean mouseReleased(Click click) { dragging = null; return super.mouseReleased(click); }
}
