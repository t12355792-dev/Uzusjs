package sonar.module;

import java.util.List;

public class Setting {
    public enum Type { BOOL, NUMBER, MODE }
    public final String name;
    public final Type type;
    public boolean bool;
    public double value, min, max, step;
    public List<String> modes;
    public int index;

    private Setting(String n, Type t) { name = n; type = t; }

    public static Setting bool(String n, boolean def) { Setting s = new Setting(n, Type.BOOL); s.bool = def; return s; }
    public static Setting number(String n, double def, double min, double max, double step) {
        Setting s = new Setting(n, Type.NUMBER); s.value = def; s.min = min; s.max = max; s.step = step; return s;
    }
    public static Setting mode(String n, int def, String... modes) {
        Setting s = new Setting(n, Type.MODE); s.modes = List.of(modes); s.index = def; return s;
    }

    public void setFromRatio(double r) {
        r = Math.max(0, Math.min(1, r));
        double v = min + (max - min) * r;
        value = Math.round(v / step) * step;
        value = Math.max(min, Math.min(max, value));
    }
    public double ratio() { return (value - min) / (max - min); }
    public String mode() { return modes.get(index); }
    public void cycle() { index = (index + 1) % modes.size(); }
    public String display() {
        return switch (type) {
            case BOOL -> bool ? "ON" : "OFF";
            case NUMBER -> step >= 1 ? String.valueOf((int) value) : String.format("%.2f", value);
            case MODE -> mode();
        };
    }
}
