package sonar.module;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.Comparator;
import java.util.Random;

/** Silent-аура: поворот уходит пакетом, камера игрока не двигается. */
public class AttackAura extends Module {
    private final Random rnd = new Random();
    public final Setting bypass = add(Setting.mode("Bypass", 0, "None", "ReallyWorld", "SkyCave"));
    public final Setting range = add(Setting.number("Range", 3.0, 2.0, 6.0, 0.1));
    public final Setting rotSpeed = add(Setting.number("Rotation speed", 60, 10, 180, 5));
    public final Setting cooldown = add(Setting.bool("Wait cooldown", true));
    public final Setting hitChance = add(Setting.number("Hit chance %", 100, 30, 100, 5));
    public final Setting skipInvisible = add(Setting.bool("Skip invisible", false));

    private float serverYaw, serverPitch;
    private boolean init;
    private int delay;

    public AttackAura() { super("Attack Aura", "Combat", "Silent-наведение головы и атака игроков"); }

    @Override public void onEnable() { init = false; }

    @Override
    public void onTick(MinecraftClient mc) {
        var p = mc.player;
        if (p == null || mc.interactionManager == null || mc.getNetworkHandler() == null) return;
        if (!init) { serverYaw = p.getYaw(); serverPitch = p.getPitch(); init = true; }

        // Пресеты обхода (подбираются опытным путём под сервер)
        String b = bypass.mode();
        double maxRange = range.value, speed = rotSpeed.value, jitter = 0;
        boolean strictCd = cooldown.bool;
        int extraDelay = 0;
        switch (b) {
            case "ReallyWorld" -> { maxRange = Math.min(maxRange, 3.0); speed = Math.min(speed, 55); jitter = 1.4; strictCd = true; extraDelay = rnd.nextInt(3); }
            case "SkyCave"     -> { maxRange = Math.min(maxRange, 3.1); speed = Math.min(speed, 70); jitter = 0.9; strictCd = true; extraDelay = rnd.nextInt(2); }
            default -> {}
        }

        final double r = maxRange;
        PlayerEntity target = mc.world.getPlayers().stream()
                .filter(e -> e != p && e.isAlive() && !e.isSpectator())
                .filter(e -> !(skipInvisible.bool && e.isInvisible()))
                .filter(e -> p.distanceTo(e) <= r)
                .min(Comparator.comparingDouble(p::distanceTo)).orElse(null);
        if (target == null) { serverYaw = p.getYaw(); serverPitch = p.getPitch(); return; }

        Vec3d eye = p.getEyePos();
        double dx = target.getX() - eye.x;
        double dy = target.getY() + target.getHeight() * 0.65 - eye.y;
        double dz = target.getZ() - eye.z;
        float wantYaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float wantPitch = (float) -Math.toDegrees(Math.atan2(dy, Math.hypot(dx, dz)));
        if (jitter > 0) {
            wantYaw += (float) ((rnd.nextDouble() - 0.5) * 2 * jitter);
            wantPitch += (float) ((rnd.nextDouble() - 0.5) * jitter);
        }

        boolean smooth = !b.equals("None");
        float dyaw = MathHelper.wrapDegrees(wantYaw - serverYaw);
        float dpitch = wantPitch - serverPitch;
        float sy = smooth ? MathHelper.clamp(dyaw, (float) -speed, (float) speed) : dyaw;
        float sp = smooth ? MathHelper.clamp(dpitch, (float) -speed / 2f, (float) speed / 2f) : dpitch;

        // GCD-фикс под чувствительность мыши
        double sens = mc.options.getMouseSensitivity().getValue() * 0.6 + 0.2;
        double gcd = sens * sens * sens * 8.0 * 0.15;
        float newYaw = serverYaw + (float) (Math.round(sy / gcd) * gcd);
        float newPitch = MathHelper.clamp(serverPitch + (float) (Math.round(sp / gcd) * gcd), -90f, 90f);
        serverYaw = newYaw; serverPitch = newPitch;

        send(mc, newYaw, newPitch); // только пакет, камера на месте

        boolean aimed = Math.abs(MathHelper.wrapDegrees(wantYaw - newYaw)) < (smooth ? 12 : 180);
        if (delay > 0) delay--;
        else if (aimed && (!strictCd || p.getAttackCooldownProgress(0.5f) >= 0.95f)
                && rnd.nextInt(100) < hitChance.value) {
            mc.interactionManager.attackEntity(p, target);
            p.swingHand(Hand.MAIN_HAND);
            delay = extraDelay;
        }
        send(mc, p.getYaw(), p.getPitch()); // возвращаем реальный поворот
    }

    private void send(MinecraftClient mc, float yaw, float pitch) {
        var p = mc.player;
        mc.getNetworkHandler().sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(yaw, pitch, p.isOnGround(), p.horizontalCollision));
    }
}
