package sonar.module;

import net.minecraft.client.MinecraftClient;
import java.util.ArrayList;
import java.util.List;

public class ModuleManager {
    public static final List<Module> modules = new ArrayList<>();
    public static AttackAura attackAura;
    public static AutoTotem autoTotem;
    public static NoWeb noWeb;

    public static void init() {
        attackAura = new AttackAura();
        autoTotem = new AutoTotem();
        noWeb = new NoWeb();
        modules.add(attackAura);
        modules.add(autoTotem);
        modules.add(noWeb);
    }
    public static void tick(MinecraftClient mc) {
        for (Module m : modules) if (m.enabled) m.onTick(mc);
    }
    public static List<Module> byCategory(String c) {
        return modules.stream().filter(m -> m.category.equals(c)).toList();
    }
}
