package sonar.module;

import net.minecraft.client.MinecraftClient;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;

public class AutoTotem extends Module {
    public final Setting hearts = add(Setting.number("Hearts", 3, 1, 10, 1));
    public final Setting delayTicks = add(Setting.number("Delay (ticks)", 0, 0, 10, 1));
    private int wait;

    public AutoTotem() { super("Auto Totem", "Combat", "Берёт тотем в левую руку при низком HP"); }

    @Override
    public void onTick(MinecraftClient mc) {
        var p = mc.player;
        if (p == null || mc.interactionManager == null) return;
        if (p.getHealth() > hearts.value * 2.0) { wait = 0; return; }
        if (p.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) return;
        if (wait++ < delayTicks.value) return;

        for (int i = 0; i < 36; i++) {
            if (p.getInventory().getStack(i).isOf(Items.TOTEM_OF_UNDYING)) {
                int slot = i < 9 ? i + 36 : i;
                mc.interactionManager.clickSlot(p.playerScreenHandler.syncId, slot, 40, SlotActionType.SWAP, p);
                wait = 0;
                return;
            }
        }
    }
}
