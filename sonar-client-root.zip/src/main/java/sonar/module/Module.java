package sonar.module;

import net.minecraft.client.MinecraftClient;
import java.util.ArrayList;
import java.util.List;

public abstract class Module {
    public final String name, category, description;
    public boolean enabled;
    public final List<Setting> settings = new ArrayList<>();

    protected Module(String name, String category, String description) {
        this.name = name; this.category = category; this.description = description;
    }
    protected Setting add(Setting s) { settings.add(s); return s; }
    public void toggle() { enabled = !enabled; if (enabled) onEnable(); else onDisable(); }
    public void onEnable() {}
    public void onDisable() {}
    public void onTick(MinecraftClient mc) {}
}
