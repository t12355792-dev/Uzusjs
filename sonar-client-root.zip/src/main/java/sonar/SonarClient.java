package sonar;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;
import sonar.gui.ClickGui;
import sonar.module.ModuleManager;

public class SonarClient implements ClientModInitializer {
    private boolean wasDown = false;

    @Override
    public void onInitializeClient() {
        ModuleManager.init();
        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            if (mc.getWindow() == null) return;
            // Right Shift открывает меню
            boolean down = GLFW.glfwGetKey(mc.getWindow().getHandle(), GLFW.GLFW_KEY_RIGHT_SHIFT) == GLFW.GLFW_PRESS;
            if (down && !wasDown && mc.currentScreen == null && mc.player != null) {
                mc.setScreen(new ClickGui());
            }
            wasDown = down;
            if (mc.player != null && mc.world != null) ModuleManager.tick(mc);
        });
    }
}
