Sonar Client - Fabric 1.21.11
Сборка: ./gradlew build  (JDK 21; wrapper можно взять из шаблона на fabricmc.net/develop)
Jar: build/libs/sonar-client-1.0.0.jar -> в папку mods (+ Fabric API)
Меню: Right Shift
Версии в gradle.properties сверь с https://fabricmc.net/develop
